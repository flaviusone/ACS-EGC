﻿//-------------------------------------------------------------------------------------------------
// Descriere: fisier main
//
// Autor: student
// Data: today
//-------------------------------------------------------------------------------------------------

//incarcator de meshe
#include "lab_mesh_loader.hpp"

//geometrie: drawSolidCube, drawWireTeapot...
#include "lab_geometry.hpp"

//incarcator de shadere
#include "lab_shader_loader.hpp"

//interfata cu glut, ne ofera fereastra, input, context opengl
#include "lab_glut.hpp"

//texturi
#include "lab_texture_loader.hpp"

#include "model.hpp"
#include "Particle.hpp"	//Dat conding style consistency..
#include <stdlib.h>
#include <time.h>

//time
#include <ctime>


class Laborator : public lab::glut::WindowListener{

//variabile
private:
	glm::mat4 model_matrix, view_matrix, projection_matrix;								//matrici 4x4 pt modelare vizualizare proiectie
	unsigned int gl_program_shader_phong;												//id obiect shader phong
	unsigned int gl_program_shader_curent;												//id obiect shader curent
	unsigned int gl_particle_shader;

	lab::Model heads[4];

	glm::vec3 light_position;
	glm::vec3 eye_position;
	unsigned int material_shininess;
	float material_kd;
	float material_ks;

	unsigned int face_texture, particle_texture;
	int timp, ind, timp2;
	std::vector<Particle*> particles;

//metode
public:
	
	//constructor .. e apelat cand e instantiata clasa
	Laborator(){
		srand(time(NULL));
		timp = timp2 = ind = 0;

		//setari pentru desenare, clear color seteaza culoarea de clear pentru ecran (format R,G,B,A)
		glClearColor(0.5,0.5,0.5,1);
		glClearDepth(1);			//clear depth si depth test (nu le studiem momentan, dar avem nevoie de ele!)
		glEnable(GL_DEPTH_TEST);	//sunt folosite pentru a determina obiectele cele mai apropiate de camera (la curs: algoritmul pictorului, algoritmul zbuffer)
		
		//incarca un shader din fisiere si gaseste locatiile matricilor relativ la programul creat
		gl_program_shader_phong = lab::loadShader("shadere\\shader_phong_vertex.glsl", "shadere\\shader_phong_fragment.glsl");
		gl_program_shader_curent = gl_program_shader_phong;
		gl_particle_shader = lab::loadShader("shadere\\shader_particle_vertex.glsl", "shadere\\shader_particle_fragment.glsl");
		
		
		lab::loadObj("resurse\\girl_sleep.obj",		heads[0].vao, heads[0].vbo, heads[0].ibo, heads[0].num_indices);	
		lab::loadObj("resurse\\girl_surprise.obj",	heads[1].vao, heads[1].vbo, heads[1].ibo, heads[1].num_indices);	
		lab::loadObj("resurse\\girl_annoyed.obj",	heads[2].vao, heads[2].vbo, heads[2].ibo, heads[2].num_indices);
		lab::loadObj("resurse\\girl_sleep.obj",		heads[3].vao, heads[3].vbo, heads[3].ibo, heads[3].num_indices);
		
		face_texture = lab::loadTextureBMP("resurse\\girl_texture.bmp");
		particle_texture = lab::loadTextureBMP("resurse\\music.bmp");
		
		for(int i = 0; i < 4; i++) {
			bind(i);
		}

		
		for(int i = 0; i < 1000; i++){
			Particle *particle = new Particle();
			addParticleThingy(particle);
			particle->speed = glm::vec3((float)rand() / RAND_MAX, (float)rand() / RAND_MAX, 0);
			particle->color = glm::vec3((float)rand() / RAND_MAX, (float)rand() / RAND_MAX, (float)rand() / RAND_MAX);
			particles.push_back(particle);
		}
		
		//lumina & material
		eye_position = glm::vec3(0,0,30);
		light_position = glm::vec3(10,30,50);
		material_shininess = 100;
		material_kd = 0.5;
		material_ks = 0.2f;


		//matrici de modelare si vizualizare
		model_matrix = glm::mat4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);
		view_matrix = glm::lookAt(eye_position, glm::vec3(0,0,0), glm::vec3(0,1,0));

		//desenare wireframe
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}

	//destructor .. e apelat cand e distrusa clasa
	~Laborator(){
		//distruge shadere
		glDeleteProgram(gl_program_shader_phong);
		glDeleteProgram(gl_particle_shader);
	}

	void bind(int i){
		glBindVertexArray(heads[i].vao);
		glBindBuffer(GL_ARRAY_BUFFER, heads[(i+1)%4].vbo);
		glEnableVertexAttribArray(3);
		glVertexAttribPointer(3,3,GL_FLOAT,GL_FALSE,sizeof(lab::VertexFormat),(void*)0);					
		glEnableVertexAttribArray(4);
		glVertexAttribPointer(4,3,GL_FLOAT,GL_FALSE,sizeof(lab::VertexFormat),(void*)(sizeof(float)*3));	
		glEnableVertexAttribArray(5);
		glVertexAttribPointer(5,2,GL_FLOAT,GL_FALSE,sizeof(lab::VertexFormat),(void*)(2*sizeof(float)*3));
	}

	void addParticleThingy(Particle *p){
		//incarca vertecsii si indecsii din fisier
		std::vector<lab::VertexFormat> vertices;
		std::vector<unsigned int> indices;
		int n = 1;
		vertices.push_back(lab::VertexFormat(-n, -n, 0, 0, 0));
		vertices.push_back(lab::VertexFormat( n, -n, 0, 1, 0));
		vertices.push_back(lab::VertexFormat( n,  n, 0, 1, 1));
		vertices.push_back(lab::VertexFormat(-n,  n, 0, 0, 1));

		indices.push_back(0);
		indices.push_back(1);
		indices.push_back(2);
		indices.push_back(0);
		indices.push_back(2);
		indices.push_back(3);


		//creeaza obiectele OpenGL necesare desenarii
		unsigned int gl_vertex_array_object, gl_vertex_buffer_object, gl_index_buffer_object;

		//vertex array object -> un obiect ce reprezinta un container pentru starea de desenare
		glGenVertexArrays(1, &gl_vertex_array_object);
		glBindVertexArray(gl_vertex_array_object);

		//vertex buffer object -> un obiect in care tinem vertecsii
		glGenBuffers(1,&gl_vertex_buffer_object);
		glBindBuffer(GL_ARRAY_BUFFER, gl_vertex_buffer_object);
		glBufferData(GL_ARRAY_BUFFER, vertices.size()*sizeof(lab::VertexFormat), &vertices[0], GL_STATIC_DRAW);

		//index buffer object -> un obiect in care tinem indecsii
		glGenBuffers(1,&gl_index_buffer_object);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gl_index_buffer_object);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size()*sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);

		//legatura intre atributele vertecsilor si pipeline, datele noastre sunt INTERLEAVED.
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(lab::VertexFormat),(void*)0);						//trimite pozitii pe pipe 0
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(lab::VertexFormat),(void*)(2*sizeof(float)*3));		//trimite texcoords pe pipe 2
		
		p->vao = gl_vertex_array_object;
		p->vbo = gl_vertex_buffer_object;
		p->ibo = gl_index_buffer_object;
		p->num_indices = indices.size();
	}

	//--------------------------------------------------------------------------------------------
	//functii de cadru ---------------------------------------------------------------------------

	//functie chemata inainte de a incepe cadrul de desenare, o folosim ca sa updatam situatia scenei ( modelam/simulam scena)
	void notifyBeginFrame(){
		timp++;
		timp2++;
		if(timp == 180)
			ind++;
		
		ind %= 4;
		timp %= 180;
		timp2 %= 180 * 4;		
	}
	//functia de afisare (lucram cu banda grafica)
	void notifyDisplayFrame(){
		//bufferele din framebuffer sunt aduse la valorile initiale (setate de clear color si cleardepth)
		//adica se sterge ecranul si se pune culoare (si alte propietati) initiala
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		
		//foloseste shaderul
		glUseProgram(gl_program_shader_curent);

		glm::mat4 matrice_cap = glm::translate(model_matrix, glm::vec3(0, -70, 0));
		matrice_cap = glm::scale(matrice_cap, glm::vec3(10,10,10));
		
		//trimite variabile uniforme la shader
		glUniformMatrix4fv(glGetUniformLocation(gl_program_shader_curent, "model_matrix"),1,false,glm::value_ptr(matrice_cap));
		glUniformMatrix4fv(glGetUniformLocation(gl_program_shader_curent, "view_matrix"),1,false,glm::value_ptr(view_matrix));
		glUniformMatrix4fv(glGetUniformLocation(gl_program_shader_curent, "projection_matrix"),1,false,glm::value_ptr(projection_matrix));
		glUniform3f(glGetUniformLocation(gl_program_shader_curent, "light_position"),light_position.x, light_position.y, light_position.z);
		glUniform3f(glGetUniformLocation(gl_program_shader_curent, "eye_position"),eye_position.x, eye_position.y, eye_position.z);
		glUniform1i(glGetUniformLocation(gl_program_shader_curent, "material_shininess"),material_shininess);
		glUniform1f(glGetUniformLocation(gl_program_shader_curent, "material_kd"),material_kd);
		glUniform1f(glGetUniformLocation(gl_program_shader_curent, "material_ks"),material_ks);
		glUniform1f(glGetUniformLocation(gl_program_shader_curent, "time"),(float)timp);
		
		//bind obiect
		glBindVertexArray(heads[ind].vao);
		glDrawElements(GL_TRIANGLES, heads[ind].num_indices, GL_UNSIGNED_INT, 0);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, face_texture);
		glUniform1i(glGetUniformLocation(gl_program_shader_curent, "textura1"), 0);
		
		if(timp2 < 180 * 2){
			glUseProgram(gl_particle_shader);
			glUniformMatrix4fv(glGetUniformLocation(gl_particle_shader, "view_matrix"),1,false,glm::value_ptr(view_matrix));
			glUniformMatrix4fv(glGetUniformLocation(gl_particle_shader, "projection_matrix"),1,false,glm::value_ptr(projection_matrix));
			glUniform1f(glGetUniformLocation(gl_particle_shader, "time"),(float)timp2);

			for(int i = 0; i < particles.size(); i++){
				glUniform3f(glGetUniformLocation(gl_particle_shader, "in_color"),particles[i]->color.x, particles[i]->color.y, particles[i]->color.z);
				glUniform3f(glGetUniformLocation(gl_particle_shader, "velocity"),particles[i]->speed.x, particles[i]->speed.y, particles[i]->speed.z);
				glBindVertexArray(particles[i]->vao);
				glDrawElements(GL_TRIANGLES, particles[i]->num_indices, GL_UNSIGNED_INT, 0);
		
				glActiveTexture(GL_TEXTURE0 + 1);
				glBindTexture(GL_TEXTURE_2D, particle_texture);
				glUniform1i(glGetUniformLocation(gl_particle_shader, "textura1"), 1);
			}
		}
	}
	//functie chemata dupa ce am terminat cadrul de desenare (poate fi folosita pt modelare/simulare)
	void notifyEndFrame(){}
	//functei care e chemata cand se schimba dimensiunea ferestrei initiale
	void notifyReshape(int width, int height, int previos_width, int previous_height){
		//reshape
		if(height==0) height=1;
		glViewport(0,0,width,height);
		projection_matrix = glm::perspective(90.0f, (float)width/(float)height,0.1f, 10000.0f);
	}


	//--------------------------------------------------------------------------------------------
	//functii de input output --------------------------------------------------------------------
	
	//tasta apasata
	void notifyKeyPressed(unsigned char key_pressed, int mouse_x, int mouse_y){
		if(key_pressed == 27) lab::glut::close();	//ESC inchide glut si 
		if(key_pressed == 32) {
			//SPACE reincarca shaderul si recalculeaza locatiile (offseti/pointeri)
			glDeleteProgram(gl_program_shader_phong);
			glDeleteProgram(gl_particle_shader);
			gl_program_shader_phong = lab::loadShader("shadere\\shader_phong_vertex.glsl", "shadere\\shader_phong_fragment.glsl");
			gl_particle_shader = lab::loadShader("shadere\\shader_particle_vertex.glsl", "shadere\\shader_particle_fragment.glsl");
			gl_program_shader_curent = gl_program_shader_phong;
		}
		if(key_pressed == 'w'){
			static bool wire =true;
			wire=!wire;
			glPolygonMode(GL_FRONT_AND_BACK, (wire?GL_LINE:GL_FILL));
		}
	}
	//tasta ridicata
	void notifyKeyReleased(unsigned char key_released, int mouse_x, int mouse_y){	}
	//tasta speciala (up/down/F1/F2..) apasata
	void notifySpecialKeyPressed(int key_pressed, int mouse_x, int mouse_y){
		if(key_pressed == GLUT_KEY_F1) lab::glut::enterFullscreen();
		if(key_pressed == GLUT_KEY_F2) lab::glut::exitFullscreen();
	}
	//tasta speciala ridicata
	void notifySpecialKeyReleased(int key_released, int mouse_x, int mouse_y){}
	//drag cu mouse-ul
	void notifyMouseDrag(int mouse_x, int mouse_y){ }
	//am miscat mouseul (fara sa apas vreun buton)
	void notifyMouseMove(int mouse_x, int mouse_y){ }
	//am apasat pe un boton
	void notifyMouseClick(int button, int state, int mouse_x, int mouse_y){ }
	//scroll cu mouse-ul
	void notifyMouseScroll(int wheel, int direction, int mouse_x, int mouse_y){ std::cout<<"Mouse scroll"<<std::endl;}

};

int main(){
	//initializeaza GLUT (fereastra + input + context OpenGL)
	lab::glut::WindowInfo window(std::string("lab shadere 1"),800,600,100,100,true);
	lab::glut::ContextInfo context(3,3,false);
	lab::glut::FramebufferInfo framebuffer(true,true,true,true);
	lab::glut::init(window,context, framebuffer);

	//initializeaza GLEW (ne incarca functiile openGL, altfel ar trebui sa facem asta manual!)
	glewExperimental = true;
	glewInit();
	std::cout<<"GLEW:initializare"<<std::endl;

	//creem clasa noastra si o punem sa asculte evenimentele de la GLUT
	//DUPA GLEW!!! ca sa avem functiile de OpenGL incarcate inainte sa ii fie apelat constructorul (care creeaza obiecte OpenGL)
	Laborator mylab;
	lab::glut::setListener(&mylab);

	//taste
	std::cout<<"Taste:"<<std::endl<<"\tESC ... iesire"<<std::endl<<"\tSPACE ... reincarca shadere"<<std::endl<<"\tw ... toggle wireframe"<<std::endl;
	std::cout<<"\t1 ... foloseste shader Gouraud"<<std::endl<<"\t2 ... foloseste shader Phong"<<std::endl;

	//run
	lab::glut::run();

	return 0;
}