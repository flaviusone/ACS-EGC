Elemente de Grafica pe Calculator(EGC) - Tema 4
    Ojog Cristian - Octavian 331 CA
    
1. CERINTA:
    Implementati un sistem de animatie faciala ce reactioneaza la un sistem de 
    particule.
    
2. UTILIZARE:
    Input:
        there is none

3. IMPLEMENTARE:
    Am codat in Visual Studio 2012, pe Windows 8. 
    Frameworkul folosit a fost cel pus la dispozitie in cadrul ultimelor 4 laboratoare.
    
    Animatia fetei:
    Dupa incarcarea obj-urilor apelez functia bind pentru fiecare care trimite pe 
    cele 3 layout-uri adaugate in shader si pozitiile, normalele si textura pt starea urmatoare.
    La fiecare 180 de frame-uri trec dintr-o stare in alta.
    
    Sistemul de particule:
    Instantiez 1000 de particule, fiecare cu o culoare random si o viteza (vec3) random.
    Pentru particule am creat un shader separat.
    Fiecare particula este un patrat in care am pus de mana texcoords pe care le voi transmite ulterior shaderului.
    In shader elimin orice punct care ar avea culoarea alba (ramane astfel doar nota muzicala peste care pun culoarea).
    Apoi mut particula adunand viteza * timp.
    Particula este animata doar in perioadele sleep->surprised si surprised->angry.
    
4. TESTARE:
    Testarea a fost facuta pe Windows 8 in Visual Studio 2012.

5. PROBLEME APARUTE:
    None.
    
6. CONTINUTUL ARHIVEI:
    Tot proiectul de Visual Studio care contine:
        -main.cpp
        -framework-ul din lab gl_4 si gl_5
        -clase pentru fiecare obiect:
            -Model
            -Particle
           
7. FUNCTIONALITATI:
    -Cele precizate in enunt.
    
    