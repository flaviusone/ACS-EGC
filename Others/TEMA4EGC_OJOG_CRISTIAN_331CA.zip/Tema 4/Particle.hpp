#include "dependente\glm\glm.hpp"
class Particle{
public:
	Particle() {}
	~Particle() {}
	glm::vec3 initPos, speed, color;
	unsigned int vbo, ibo, vao, num_indices;	
private:
	//nimic.. gen
};