#include <vector>
#include "dependente\glm\glm.hpp"

namespace lab{

class Model
{
public:
	Model() {}
	~Model() {}

	unsigned int vbo, ibo, vao, num_indices;	
};

}